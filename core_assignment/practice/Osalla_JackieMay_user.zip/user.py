
class User:
    def __init__(self, first_name, last_name, email, age):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.age = age
        #rewards member default value of false
        self.is_rewards_member = False
        self.gold_card_points = 0

    def display_info(self):
        print("========================")
        print(f'First Name: {self.first_name}\nLast Name: {self.last_name}\nEmail: {self.email}\nAge:{self.age}')
        print("========================")

    def enroll(self):
        if self.is_rewards_member == False:
            self.gold_card_points = 200
            print(f'Welcome {self.first_name}! Your gold card points is: {self.gold_card_points} ')
            return False
        else:
            print("User already a member")
            return True
    
    def spend_points(self, amount):
        if self.gold_card_points < amount:
            print("You do not have enough Points to spend")
        else:
            self.amount = self.gold_card_points - amount
            print(f'{self.first_name}, You have spent {amount} points and have a remaining balance of {self.amount} points')



user1 = User("John", "O'Reily", "jor@yahoo.com", 29)
user1.display_info()
user1.enroll()
user1.spend_points(50)
user2 = User("Jaz", "O'Conner", "jazzy@gmail.com", 33)
user3 = User("Jules", "O'Farrel", "joff@hotmail.com", 23)
user2.enroll()
user2.spend_points(80)
user2.display_info()
user3.display_info()